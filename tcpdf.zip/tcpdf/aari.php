<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<style>

.vertical{
    position: relative;
     padding : 60px
}
th span {
  transform-origin: 0 50%;
  transform: rotate(-90deg);
  white-space: nowrap;
  display: block;
  position: absolute;
  bottom: 0;
  left: 50%;
}

</style>
<script>
     function a() {
         var header_height = 0;
         ('table th span').each(function a() {
             if ($(this).outerWidth() > header_height) header_height = $(this).outerWidth();
         });

         ('table th').height(header_height);
     };
</script>
<body>
    <table >
        <tr>
            <th class ="vertical" width="100px"><span> </span> </th>
            <th class ="vertical" width="30px"><span>Telinehmer</span></th>
            <th class ="vertical" width="20px"><span> Vertelier</span> </th>
            <th class ="vertical" width="170px"><span> </span> </th>
        </tr>
        <tr>
            <td >test passages, and more recently</td>
            <td align="center"> - </td>
            <td align="center"> x </td>
            <td> agmarsha 97 @gmail.com </td>
        </tr>
    </table>
</body>
</html>

<!-- $pdf->StartTransform();
$pdf->Rotate(270, 50, 60);
$pdf->Text(0,0, $signatur.$line.$title);
$pdf->StopTransform(); -->

