<?php

use MYPDF as GlobalMYPDF;

require_once ('dp.php');
require __DIR__ . '/vendor/autoload.php';
// function fetch_data(){


// Extend the TCPDF class to create custom Header and Footer
class MYPDF extends TCPDF {


   // Page header
    public function Header() {
        // Logo
        //$image_file = 'sss.jpg';
        //$this->Image($image_file, 10, 10, 20, '', 'JPG', '', 'T', false, 300, '', false, false, 1, false, false, false);
        // Set font
        //$this->SetFont('helvetica', 'B', 20);
        // Title
        //$this->Cell(0, 15, 'TCPDF is a php library', 0, false, 'C', 0, '', 0, false, 'M', 'M');
        //$this->top_margin = $this->GetY() + 5;
    }


    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('helvetica', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}


// create new PDF document
$pdf = new MYPDF('P', 'mm', 'A4', true, 'UTF-8', false);


//$pdf->AddPage();

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('TCPDF Example 003');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// // set default header data
// $pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);
$pdf->setFooterData(array(0,64,0), array(0,64,128));
// set header and footer fonts
//$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(true, 44);


// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}
// set font
$pdf->SetFont('helvetica', '', 10);

// add a page

$pdf->AddPage();
if ($dom[$key]['tag'] AND isset($dom[$key]['attribute']['pagebreak'])) {
    // check for pagebreak
    if (($dom[$key]['attribute']['pagebreak'] == 'true') OR ($dom[$key]['attribute']['pagebreak'] == 'left') OR ($dom[$key]['attribute']['pagebreak'] == 'right')) {
        // add a page (or trig AcceptPageBreak() for multicolumn mode)
        $this->checkPageBreak($this->PageBreakTrigger + 1);
    }
    if ((($dom[$key]['attribute']['pagebreak'] == 'left') AND (((!$this->rtl) AND (($this->page % 2) == 0)) OR (($this->rtl) AND (($this->page % 2) != 0))))
            OR (($dom[$key]['attribute']['pagebreak'] == 'right') AND (((!$this->rtl) AND (($this->page % 2) != 0)) OR (($this->rtl) AND (($this->page % 2) == 0))))) {
        // add a page (or trig AcceptPageBreak() for multicolumn mode)
        $this->checkPageBreak($this->PageBreakTrigger + 1);
    }
}
//$pdf->Rect(160,30,220,220);
// $pdf->ScaleXY(150, 50, 80);
// $pdf->Rect(5, 5, 100, 5, 'D');
// $pdf->Text(50, 66, 'Scale');
// // Stop Transformation
// $pdf->StopTransform();

// $pdf->StartTransform();
// // Translate 7 to the right, 5 to the bottom
// $pdf->Translate(50, 70);
// $pdf->Text(12, 66, 'Translate');
// // Stop Transformation
// $pdf->StopTransform();

// Start Transformation
$pdf->StartTransform();
// Rotate 20 degrees counter-clockwise centered by (70,110) which is the lower left corner of the rectangle
$pdf->Rotate(90, 66, 89);
//$pdf->Rect(70, 100, 40, 10, 'D');
$pdf->Text(60, 96, 'Telinehmer');
// Stop Transformation
$pdf->StopTransform();

//$pdf->Rotate(270, 50, 60); must be $pdf->Rotate(270, 65, 85);
$pdf->StartTransform();
$pdf->Rotate(90, 72, 83);
$pdf->Text(60, 96, 'Vertelier');
$pdf->StopTransform();

$query ="SELECT * FROM tcpdf_data";
$result = mysqli_query($conn, $query);

$output = '<table class="tab1" width="100%" cellpadding="5px">
<tr nobr="true">
    <th width="10%" align="left" border="1">ID</th>
    <th width="70%" align="left" border="1">Beanstandung</th>
    <th width="20%" align="left" border="1">Status</th>
</tr>';

$count=0 ;
if(mysqli_num_rows($result) > 0){
    while ($row = mysqli_fetch_assoc($result)) {
$count ++;
$output.='
        <tr nobr="true">
            <td border="1">'.$row['ID'].'</td>
            <td border="1">'.$row['Beanstandung'].'</td>
            <td border="1">'.$row['Status'].'</td>
        </tr>';

    }
    $output .='</table>';
}else{
    $output = 'No record found';
}



//write some JavaScript code
$js = <<<EOD
document.getElementById('test').style.color = "red";

EOD;

// function a() {
//     var header_height = 0;
//     ('table th span').each(function a() {
//         if ($(this).outerWidth() > header_height) header_height = $(this).outerWidth();
//     });

//     ('table th').height(header_height);
// };
// force print dialog
// $js .= 'a();';

// set javascript
$pdf->IncludeJS($js);



// // Set some content to print
$html = <<<EOF

<style>
</style>
<div position= "static">
    <div class="test1" >
        <img src="aa.jpg" alt="sss" width = "70px" height = "50px">
        <p id='test'><b>HPI HIMMEN </b></p>
        <p>Ingenieurgesellschaft<br>fur technische<br>Gebaudeausrustung<br></p>
    </div>
    <br>
    <div class="test2" >
        <p align="left"><b>Es schreibt ihnen</b><br>i.V Admin HPI
        <br><br><strong>Telefon
        <br><br>Unser Zeichen
        <br><br>Datum
        <br></strong>2022-04-25
        </p>
    </div>

    <div class="test3">
        <p><strong>HPI HIMMEN</strong></p>
        <p>Ingenieurgesellschaft
        <br>mbH & Co.KG
        <br>
        <br>
        <br>TEL FAX
        <br>
        <br>Komplementain:<br>Himmen Beteiligungs-Gm<br>bH, Sitz: AndernachAmt<br>sgericht KoblenzHRB 14<br>793
        <br>
        <br><strong>Geschaftsfuhrer</strong>
        <br>Dipl.-lng.(FH)
        <br>Frank kKarst
        <br>Dipl.-lng. (FH)
        <br>Andreas Weinreis
        <br>
        <br>www.hpi-himmen.de
        </p>
    </div>
</div>


EOF;


$html2 = <<<EOF
<style>
.vertical{
    position: relative;
     padding : 60px
}
th span {
  transform-origin: 0 50%;
  transform: rotate(-90deg);
  white-space: nowrap;
  display: block;
  position: absolute;
  bottom: 0;
  left: 50%;
}
</style>

<div class="text4">
    <h3>Test Company</h3>
    <p><b>Project: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>Test-Ar2-111 (123456)</span></b></p>
    <br>

    <br>
    <p>Besprechung :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>city</span> </p>
    <p>Ort : </p>
    <p>Thema :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>test</span></p>
    <br>
    <br>
    <br>
</div>
<br>
<br>
<br>

<table>
    <tr>
       <th width="190px"> </th>
       <th style = "webkit-writing-mode: vertical-rl;" width="40px">    </th>
       <th style = "transform: rotate(-180deg);-webkit-writing-mode: vertical-rl;" width="40px">  </th>
       <th width="170px"> </th>
    </tr>
    <br>
    <br>
    <br>
    <br>
    <tr>
        <td>test passages, and more recently</td>
        <td align="center"> - </td>
        <td align="center"> x </td>
        <td> agmarsha 97 @gmail.com </td>
    </tr>
</table>

<br><br> <br>
$output

<h1>H P I H I M M E N</h1>
<p>Ingenieurgesellschaft</p>
<br> <br><br>
<p> j.V.Admin HPI </p>

EOF;

$style = array('width' => 0.1, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array(0, 0, 0));
$pdf->Line(150, 10, 195, 10, $style );
$pdf->Line(150, 10, 150, 280, $style);
$pdf->Line(150, 280, 195, 280, $style);

$pdf->Line(15, 35, 144, 35, $style);
$pdf->Line(15, 70, 144, 70, $style);



//test1 position only change l,r,t,b
//$pdf->setCellPaddings( $left = '0', $top = '0', $right = '0', $bottom = '0');
//$pdf->writeHTML($html, true, false, true, false, 'C');
$pdf->writeHTMLCell(50, 100, 155, 12, $html, 0, 1, 0, true, 'L', true);
$pdf->writeHTMLCell(130, 100, 15, 10, $html2, 0, 1, 0, true, 'L', true);






//$pdf->writeHTML($html2, true, false, true, false, 'C');

// $pdf->AddPage();

// $style = array('width' => 0.1, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array(0, 0, 0));
// $pdf->Line(150, 25, 195, 25, $style);
// $pdf->Line(150, 25, 150, 280, $style);
// $pdf->Line(150, 280, 195, 280, $style);


// $pdf->writeHTML($html, true, false, true, false, '');

// $pdf->writeHTMLCell(80, '', '', $y, $left_column, 1, 0, 1, true, '', true);


//cell
//$pdf->Ln(10); // Line gap
// $pdf->SetX(150); // abscissa of Horizontal position
// $pdf->MultiCell(60,250,'TCPDF library file',1,'C',false);


// Print text using writeHTMLCell()
//$pdf->writeHTMLCell(40, 245, '', '', 'TCPDF is a php library.', 1, 1, 0, true, '', true);

// $pdf->Cell(30, 100, 'LTB', 'LTB', 1, 'C', 1, '', 0, false, 'T', 'C');
// $pdf->Ln(2);

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('example_003.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+
?>