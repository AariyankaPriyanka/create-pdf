<?php
    $dbHost = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "tcpdf";

    $conn = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
    //echo "db connected";

    if($conn->error){
        die('db not connected' .$conn->error);
    }

?>